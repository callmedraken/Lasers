import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

/**
 * Created by Michael on 4/11/2016.
 * John Hsiao
 */
public class LasersPTUI
{
    private int row, col;  // row is amount of rows, col is amount of cols
    private char[][] grid;  // 2D char array of the grid

    /**
     * creates the grid
     * @param keyboard is the file
     */
    public LasersPTUI(Scanner keyboard)
    {
        this.row = keyboard.nextInt();
        this.col = keyboard.nextInt();
        this.grid = new char[this.row][this.col];
        for (int r = 0; r < this.row; r++)
        {
            for (int c = 0; c < col; c++)
            {
                this.grid[r][c] = keyboard.next().charAt(0);
            }
        }
    }

    /**
     * displays help menu
     */
    public static void help()
    {
        System.out.println("a|add r c: Add laser to (r,c)\n"+
        "d|display: Display safe\n"+
        "h|help: Print this help message\n"+
        "q|quit: Exit program\n"+
        "r|remove r c: Remove laser from (r,c)\n"+
        "v|verify: Verify safe correctness");
    }

    /**
     * exits program with code 0
     */
    public static void quit()
    {
        System.exit(0);
    }


    /**
     * adds laser to coords and beams vertically and horizontally
     * @param r - row
     * @param c - column
     */
    public void add(int r, int c)
    {
        if ((r < 0) || (c < 0) || (r >= this.row) || (c >= this.col) || ((this.grid[r][c] != '.') && (this.grid[r][c] != '*')))
        {
            System.out.println("Error adding laser at: (" + r + ", " + c + ")");
        }
        else
        {
            this.grid[r][c] = 'L';
            int currR = r;
            int currC = c;
            // lasers going up
            while(currR > 0){
                currR--;
                if((this.grid[currR][c] == '.') || (this.grid[currR][c] == '*'))
                {
                    this.grid[currR][c] = '*';
                }
                else
                {
                    break;
                }
            }
            currR = r;
            // lasers going down
            while(currR < this.row-1){
                currR++;
                if((this.grid[currR][c] == '.') || (this.grid[currR][c] == '*'))
                {
                    this.grid[currR][c] = '*';
                }
                else
                {
                    break;
                }
            }
            // lasers going left
            while(currC > 0){
                currC--;
                if((this.grid[r][currC] == '.') || (this.grid[r][currC] == '*'))
                {
                    this.grid[r][currC] = '*';
                }
                else
                {
                    break;
                }
            }
            currC = c;
            // lasers going right
            while(currC < this.col-1){
                currC++;
                if((this.grid[r][currC] == '.') || (this.grid[r][currC] == '*'))
                {
                    this.grid[r][currC] = '*';
                }
                else
                {
                    break;
                }
            }
            System.out.println("Laser added at: (" + r + ", " + c + ")");
        }
        this.display();
    }

    /**
     * removes laser from coords and beams
     * @param r - row
     * @param c - column
     */
    public void remove(int r, int c)
    {
        if ((r < 0) || (c < 0) || (r >= this.row) || (c >= this.col) || (this.grid[r][c] != 'L'))
        {
            System.out.println("Error removing laser at: (" + r + ", " + c + ")");
        }
        else
        {
            if(!laser(r, c))
            {
                this.grid[r][c] = '.';
            }
            else
            {
                this.grid[r][c] = '*';
            }
            int currR = r;
            int currC = c;

            // removing beams up
            while(currR > 0)
            {
                currR--;
                if(this.grid[currR][c] == '*')
                {
                    if (laser(currR, c))
                    {
                        continue;
                    }
                    else
                    {
                        this.grid[currR][c] = '.';
                    }
                }
                else
                {
                    break;
                }
            }
            currR = r;
            // removing beams down
            while(currR < this.row-1){
                currR++;
                if(this.grid[currR][c] == '*')
                {
                    if (laser(currR, c))
                    {
                        continue;
                    }
                    else
                    {
                        this.grid[currR][c] = '.';
                    }
                }
                else
                {
                    break;
                }
            }
            // lasers going left
            while(currC > 0){
                currC--;
                if(this.grid[r][currC] == '*')
                {
                    if (laser(r, currC))
                    {
                        continue;
                    }
                    else
                    {
                        this.grid[r][currC] = '.';
                    }
                }
                else
                {
                    break;
                }
            }
            currC = c;
            // lasers going right
            while(currC < this.col-1){
                currC++;
                if(this.grid[r][currC] == '*')
                {
                    if (laser(r, currC))
                    {
                        continue;
                    }
                    else
                    {
                        this.grid[r][currC] = '.';
                    }
                }
                else
                {
                    break;
                }
            }
            System.out.println("Laser removed at: (" + r + ", " + c + ")");
        }
        this.display();
    }

    /**
     * helper, finds laser in row or column
     * @param r - row
     * @param c - col
     * @return true if another laser is pointing at (r,c)
     */
    private boolean laser(int r, int c)
    {
        int currR = r;
        int currC = c;
        // looking up
        while(currR > 0){
            currR--;
            if(this.grid[currR][c] == 'L')
            {
                return true;
            }
            else if((this.grid[currR][c] == '.') || (this.grid[currR][c] == '*'))
            {
                continue;
            }
            else
            {
                break;
            }
        }
        currR = r;
        // looking down
        while(currR < this.row-1){
            currR++;
            if(this.grid[currR][c] == 'L')
            {
                return true;
            }
            else if((this.grid[currR][c] == '.') || (this.grid[currR][c] == '*'))
            {
                continue;
            }
            else
            {
                break;
            }
        }
        // looking left
        while(currC > 0){
            currC--;
            if(this.grid[r][currC] == 'L')
            {
                return true;
            }
            else if((this.grid[r][currC] == '.') || (this.grid[r][currC] == '*'))
            {
                continue;
            }
            else
            {
                break;
            }
        }
        currC = c;
        // looking right
        while(currC < this.col-1){
            currC++;
            if(this.grid[r][currC] == 'L')
            {
                return true;
            }
            else if((this.grid[r][currC] == '.') || (this.grid[r][currC] == '*'))
            {
                continue;
            }
            else
            {
                break;
            }
        }
        return false;
    }

    /**
     * checks the safe specifications for validity
     * if found not valid, print where it's invalid
     * @return true if safe is valid, false if otherwise
     */
    public boolean verify()
    {
        for (int r = 0; r < this.row; r++)
        {
            for (int c = 0; c < this.col; c++)
            {
                if (this.grid[r][c] == '.')
                {
                    System.out.println("Error verifying at: (" + r + ", " + c + ")");
                    this.display();
                    return false;
                }
                // if two lasers are pointing at each other
                //else if (this.laser(r,c) == true)
                //{
                 //   return false;
                //}
                else if (this.grid[r][c] == 'L')
                {
                    if (this.laser(r,c) == true)
                    {
                        System.out.println("Error verifying at: (" + r + ", " + c + ")");
                        this.display();
                        return false;
                    }
                }
                else
                {
                    if (Character.isDigit(this.grid[r][c]))
                    {
                        int i = Character.digit(this.grid[r][c], 10);
                        int tar = 0;
                        if (c > 0 && this.grid[r][c-1] == 'L')
                        {
                            tar++;
                        }
                        if (c < col-1 && this.grid[r][c+1] == 'L')
                        {
                            tar++;
                        }
                        if (r > 0 &&this.grid[r-1][c] == 'L')
                        {
                            tar++;
                        }
                        if (r < row - 1 && this.grid[r+1][c] == 'L')
                        {
                            tar++;
                        }
                        if (tar != i)
                        {
                            System.out.println("Error verifying at: (" + r + ", " + c + ")");
                            this.display();
                            return false;
                        }
                    }
                }
            }
        }
        System.out.println("Safe is fully verified!");
        this.display();
        return true;
    }
    /**
     * displays safe in ASCII format
     */
    public void display()
    {
        String result = "  ";
        for(int i=0;i<this.col;i++)
        {
            result += i%10 + " ";
        }
        result += "\n  ";
        for(int i=0;i<this.col*2-1;i++)
        {
            result += "-";
        }
        result += "\n";
        for(int i=0; i<this.row; i++)
        {
            result += i%10 + "|";
            for(int j=0; j<this.col; j++)
            {
                result += grid[i][j] + " ";
            }
            if (i == this.row-1)
            {
                break;
            }
            result += "\n";
        }
        System.out.println(result);
    }

    /**
     * executes the program with string of input
     * @param s is the string of input
     */
    public void execute(String s)
    {
        String params[] = s.split(" ");
        if(!s.equals(""))
        {
            char c = params[0].charAt(0);
            if (c == 'q')
            {
                quit();
            }
            else if (c == 'h')
            {
                help();
            }
            else if (c == 'a')
            {
                if(params.length == 3)
                {
                    this.add(Integer.parseInt(params[1]), Integer.parseInt(params[2]));
                }
                else
                {
                    System.out.println("Incorrect coordinates");
                }
            }
            else if (c == 'd')
            {
                this.display();
            }
            else if (c == 'r')
            {
                if(params.length == 3)
                {
                    this.remove(Integer.parseInt(params[1]), Integer.parseInt(params[2]));
                }
                else
                {
                    System.out.println("Incorrect coordinates");
                }
            }
            else if (c == 'v')
            {
                this.verify();
            }
            else
            {
                System.out.println("Unrecognized command: " + params[0]);
            }
        }
    }

    /**
     * Declares our names
     * checks for valid inputs
     * @param args command line input
     * @throws FileNotFoundException
     */
    public static void main(String[] args) throws FileNotFoundException
    {
        if((args.length == 0) || (args.length > 2))
        {
            System.out.println("Usage: java LasersPTUI safe-file [input]");
            System.exit(0);
        }
        Scanner keyboard = new Scanner(new File(args[0]));
        LasersPTUI safe = new LasersPTUI(keyboard);
        keyboard.close();
        safe.display();
        if (args.length == 1)
        {
            Scanner input = new Scanner(System.in);
            while (true)
            {
                System.out.print("> ");
                String line = input.nextLine();
                safe.execute(line);
            }
        }
        if (args.length == 2)
        {
            Scanner input = new Scanner(new File(args[1]));
            while (input.hasNextLine())
            {
                String s = input.nextLine();
                System.out.println("> " + s);
                safe.execute(s);
            }
            Scanner input1 = new Scanner(System.in);
            while (true)
            {
                System.out.print("> ");
                String line = input1.nextLine();
                safe.execute(line);
            }
        }
    }
}
